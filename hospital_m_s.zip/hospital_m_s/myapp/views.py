from django.shortcuts import render
from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth import login,authenticate,logout
from .models import Patient,Doctors
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from myapp.forms import PatientForm,DoctorsForm
from datetime import date
def loginpage(request):
    if request.method=="POST":
        username=request.POST.get('username')
        password=request.POST.get('password')
        user = authenticate(request, username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('/home')
        else:
            messages.info(request, "Invalid Crendentails")
    context={}
    return render(request,"myapp/login.html",context)
def logoutAdmin(request):
    logout(request)
    return redirect('/')
@login_required(login_url='/')
def home(request):
    return render(request,'myapp/home.html')
@login_required(login_url='/')
def welcome(request):
    return render(request,'myapp/welcome.html')
@login_required(login_url='/')
def ptn(request):
    if request.method=="POST":
        form=PatientForm(request.POST)
        print(form.is_valid())
        if form.is_valid():
            try:
                form.save()
                return redirect('/show')
            except:
                pass
    else:
        form=PatientForm()
    return render(request,'myapp/index.html',{'form':form})
@login_required(login_url='/')
def view(request):
    patient=Patient.objects.all()
    return render(request,"myapp/show.html",{'patient':patient})
def delete(request,id):
    patient=Patient.objects.get(id=id)
    patient.delete()
    return redirect('/show')
def edit(request,id):
    patient=Patient.objects.get(id=id)
    form = PatientForm(instance=patient)
    if request.method=='POST':
        form = PatientForm(request.POST,instance=patient)
        print(form.is_valid())
        if form.is_valid():
            form.save()
            return redirect('/show')
    
    context = {'form':form,'id':id}
    return render(request,"myapp/edit.html",context)

def search(request):
    given_name=request.POST['name']
    patient=Patient.objects.filter(name__icontains=given_name)
    return render(request,"myapp/show.html",{'patient': patient})
@login_required(login_url='/')
def dwelcome(request):
    return render(request,'myapp/dwelcome.html')
@login_required(login_url='/')
def doc(request):
    if request.method=="POST":
        form=DoctorsForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect('/dshow')
            except:
                pass
    else:
        form=DoctorsForm()
    return render(request,'myapp/dindex.html',{'form':form})
@login_required(login_url='/')
def dshow(request):
    doctor=Doctors.objects.all()
    return render(request,"myapp/dshow.html",{'doctor':doctor})
@login_required(login_url='/')
def dedit(request,id):
    doctor=Doctors.objects.get(id=id)
    form = DoctorsForm(instance=doctor)
    if request.method=='POST':
        form = DoctorsForm(request.POST,instance=doctor)
        print(form.is_valid())
        if form.is_valid():
            form.save()
            return redirect('/dshow')
    
    context = {'form':form,'id':id}
    return render(request,"myapp/dedit.html",context)
def ddelete(request,id):
    doctor=get_object_or_404(Doctors,id=id)
    doctor.delete()
    return redirect('/dshow')
def dsearch(request):
    given_name=request.POST['name']
    doctor=Doctors.objects.filter(name__icontains=given_name)
    return render(request,"myapp/dshow.html",{'doctor': doctor})
def payment(request,id):
    patient=Patient.objects.get(id=id)
    form = PatientForm(instance=patient)
    b=Patient.objects.filter(id=id).values('medicineCost')
    c=Patient.objects.filter(id=id).values('otherCharges')
    d1=Patient.objects.filter(id=id).values('admitDate')
    d2=Patient.objects.filter(id=id).values('releaseDate')
    admit=d1[0]['admitDate']
    release=d2[0]['releaseDate']
    no_of_days=(release-admit).days
    roomcharge=100*no_of_days
    res=b[0]['medicineCost']+c[0]['otherCharges']+roomcharge
    c=Patient.objects.filter(id=id).values('Paid')
    rem=res-c[0]['Paid']
    if rem==0:
        messages.info(request,"Payment Done,Can Discharge")
    else:
        messages.info(request,"Payment pending")
    return render(request,"myapp/payment.html",{'res':res,'rem':rem,'patient':patient,'no_of_days':no_of_days,'roomcharge':roomcharge})