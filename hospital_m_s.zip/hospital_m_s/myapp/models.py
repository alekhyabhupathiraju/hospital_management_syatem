from django.db import models
class Doctors(models.Model):
    name=models.CharField(max_length=100)
    age=models.PositiveIntegerField()
    mobile_no=models.CharField(max_length=10)
    Degree=[('MBBS','MBBS'),('BDS','BDS'),('B.MED','B.MED'),('MD','MD'),('MSC','MSC')]
    degree=models.CharField(max_length=10,choices=Degree)
    specialist=[('cardiologist','cardiologist'),('dentist','dentist'),('dermatologist','dermatologist'),
                 ('gynecologist','gynecologist'),('neurologist','neurologist'),('ENT','ENT')]
    Specialized_in=models.CharField(max_length=100,choices=specialist)
    Experience=models.PositiveIntegerField()
    def __str__(self):
        return self.name
class Patient(models.Model):
    name=models.CharField(max_length=100)
    age=models.PositiveIntegerField()
    Gender=[('Male','Male'),('Female','Female')]
    gender=models.CharField(max_length=30,choices=Gender)
    address=models.CharField(max_length=1000)
    mobile_no=models.CharField(max_length=10)
    problem=models.CharField(max_length=100)
    assignedDoctor=models.ForeignKey(Doctors,on_delete=models.CASCADE,primary_key=False)
    treatment=models.CharField(max_length=100)
    admitDate=models.DateField(auto_now_add=False,auto_now=False,blank=False,null=False)
    releaseDate=models.DateField(null=False)
    medicineCost=models.IntegerField()
    otherCharges=models.IntegerField()
    Paid=models.IntegerField()
