from django.forms import ModelForm
from django import forms
from .models import Patient,Doctors
class PatientForm(ModelForm):
    class Meta:
        model=Patient
        fields="__all__"
class DoctorsForm(ModelForm):
    
    class Meta:
        model=Doctors
        fields="__all__"
