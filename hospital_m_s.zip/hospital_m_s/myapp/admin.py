from django.contrib import admin
from .models import Doctors,Patient
admin.site.register(Doctors)
admin.site.register(Patient)

# Register your models here.
